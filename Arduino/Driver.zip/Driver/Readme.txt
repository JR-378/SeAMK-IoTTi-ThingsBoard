1. Run SETUP.EXE at folder CH341SER
2. Click install
3. Wait till you get an notification that the installation is complete (takes some time)